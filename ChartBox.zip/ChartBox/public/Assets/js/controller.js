angular.module("app.controllers",[])
  .controller('mainCntrl', function(){
    console.log("main cntrl");
  })
  
  .run(function($socketservice){
    //initilise $socketservice
   
  })
  
  .controller('loginCntrl', function($scope, $state, $socketservice){
    console.log("loginCntrl");
    $scope.init= function(){
	  $scope.loginData = {
	    username:null,
		email:null
	  }
	}
	
	$scope.doLogin = function(){
	  console.log('Login', $scope.loginData);
	  //console.log($filter('date')(new Date(),'y-m');
	  var userdata = {name:$scope.loginData.username, email:$scope.loginData.email, logintime:new Date().getTime()}
	  var data = {userdata:userdata};
	  localStorage.setItem('chatBox',angular.toJson(data));
	  $state.go('home');
	}
	
    $scope.init();	
  })
  
  .controller('homeCntrl', function($scope, $state, $socketservice, $timeout, $compile){
    console.log("homeCntrl");
	
    $scope.init= function(){
	   $scope.receiver = null;
	   $scope.notification = {
	      username:'',
		  message:'',
		  showHide:false
	   }
	   if(localStorage.getItem('chatBox')!=null){
	     $scope.userdetails = angular.fromJson(localStorage.getItem('chatBox')).userdata;
	     $socketservice.setupforUser(angular.fromJson(localStorage.getItem('chatBox')).userdata);
	     // General name of the room from where you want to ge online users
	     // in future rooms can be increase
	     $socketservice.getOnlineUsers('General');
	   }else{
	     $state.go('login');
	   }
	}
	
	$scope.$on('onmessage', function(event, data){
	  console.log('$scope.onmessage');
	  console.log(data)
	   //new user joined
	  if(data.flag==1){
	    console.log('new user joined');
		if(data.email != $scope.userdetails.email){
		   $scope.notification = {
	         username:data.name,
		     message:'has joined',
		     showHide:true
	       }
		   $timeout(function(){$scope.notification.showHide=false;},3000)
		 }
		
	  }
	  if(data.flag==2){
	    console.log('get online user');
		console.log(data.onlineusers)
		$scope.$apply(function(){
		   $scope.onlineUsers = data.onlineusers;
		})
	  }
	  if(data.flag==3){
	    console.log('delete user');
		if(data.userDisconnected.emaill != $scope.userdetails.email){
		   $scope.notification = {
	         username:data.userDisconnected.name,
		     message:'has disconnected',
		     showHide:true
	       }
		   $timeout(function(){$scope.notification.showHide=false;},3000)
		 }
		for(var i=0;i<$scope.onlineUsers.length;i++){
		   console.log($scope.onlineUsers[i].email +"=="+ data.userDisconnected.email)
		  if($scope.onlineUsers[i].email == data.userDisconnected.email){
		    console.log('removing user:: '+data.userDisconnected.email)
			$scope.$apply(function(){
		      $scope.onlineUsers.splice(i,1); 
			})
		  }
		} 
	  }
	  
	  if(data.flag==4){
	    console.log(data);
		document.getElementById('chatMessages').innerHTML+= '<li class="friend-with-a-SVAGina">'
					+'<div class="head">'
						+'<span class="time">10:15 AM, Today</span>'
					+'</div>'
					+'<div class="message">'+data.message+'</div>'
				+'</li>';
				
		var objDiv = document.getElementById("chatMessages");
        objDiv.scrollTop = objDiv.scrollHeight;
	  }
	});
	
	$scope.startChat = function(user){
	  console.log('Starting chat with :: '+user);
	  $scope.receiver = user;
	}
	
	$scope.sendChatMessage = function(){
	   var data = {
	     flag:4,
		 receiver:$scope.receiver,
		 message:$scope.usermessage
	   }
	
	   document.getElementById('chatMessages').innerHTML+= '<li class="i">'
					+'<div class="head">'
						+'<span class="time">10:13 AM, Today</span>'
					+'</div>'
					+'<div class="message">'+data.message+'</div>'
				+'</li>';
		$scope.usermessage="";
	   $socketservice.sendMessages(data);
	   var objDiv = document.getElementById("chatMessages");
        objDiv.scrollTop = objDiv.scrollHeight;
	}
	
    $scope.init();	
  })
  .filter('myfilter', function(){
    return function(items, deleuseremail){
	   var filtered = [];
	   var userdetails = null;
	   if(localStorage.getItem('chatBox')!=null){
	      userdetails = angular.fromJson(localStorage.getItem('chatBox')).userdata ||{};
	   }
	   angular.forEach(items, function(item) { 
        if(item.email != userdetails.email) {
          filtered.push(item);
        }
      });
	  return filtered;
	}
  })
  
 